-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versi server:                 8.0.30 - MySQL Community Server - GPL
-- OS Server:                    Win64
-- HeidiSQL Versi:               12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- membuang struktur untuk table webpage.artikel
DROP TABLE IF EXISTS `artikel`;
CREATE TABLE IF NOT EXISTS `artikel` (
  `id_artikel` int NOT NULL AUTO_INCREMENT,
  `tanggal` varchar(250) NOT NULL DEFAULT '',
  `judul` varchar(350) NOT NULL,
  `isi` text NOT NULL,
  `gambar` varchar(150) NOT NULL,
  PRIMARY KEY (`id_artikel`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Membuang data untuk tabel webpage.artikel: ~2 rows (lebih kurang)
INSERT INTO `artikel` (`id_artikel`, `tanggal`, `judul`, `isi`, `gambar`) VALUES
	(1, 'jumat, 07-06-2024', 'bakso bang disko milik king abdi', 'Bakso Bang Disko punyanya King Abdi  Master Chef 10 ini katanya pelopor  Bakso Gepeng Pertama di Malang.Saking beraneka ragamnya bakso di Malang kadang Aku tidak aneh lagi sama pendatang baru yang jual bakso yang unik-unik. Bakso di Malang memang makanan sehari-hari yang sudah menjadi kewajiban bagi wisatawan yang berkunjung ke Malang Raya. Belum ke Malang kalau belum makan Bakso. Sebelumnya aku pernah bahas beberapa bakso legend di Malang yang sudah menjadi favoritnya aku. Tapi tak dipungkiri Aku juga selalu exited setiap mengunjungi bakso pendatang baru. ', 'gambarartikel\\baksodisko.webp'),
	(15, 'sabtu, 08-06-2024', 'test 2', 'test 2', 'gambar/2.png');

-- membuang struktur untuk table webpage.kategori
DROP TABLE IF EXISTS `kategori`;
CREATE TABLE IF NOT EXISTS `kategori` (
  `id_kategori` int NOT NULL AUTO_INCREMENT,
  `nama_kategori` varchar(50) NOT NULL DEFAULT '0',
  `keterangan` varchar(50) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_kategori`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Membuang data untuk tabel webpage.kategori: ~4 rows (lebih kurang)
INSERT INTO `kategori` (`id_kategori`, `nama_kategori`, `keterangan`) VALUES
	(1, 'wisata makanan', 'artikel yang membahas tentang makanan'),
	(2, 'wisata hiburan', 'artikel yang membahas tentang tempat hiburan'),
	(3, 'wisata religi', 'artikel yang membahas tentang tempat wisata religi'),
	(4, 'wisata mistis', 'artikel yang membahas tempat tempat angker');

-- membuang struktur untuk table webpage.kontributor
DROP TABLE IF EXISTS `kontributor`;
CREATE TABLE IF NOT EXISTS `kontributor` (
  `id_kontributor` int NOT NULL AUTO_INCREMENT,
  `id_penulis` int DEFAULT NULL,
  `id_kategori` int DEFAULT NULL,
  `id_artikel` int DEFAULT NULL,
  PRIMARY KEY (`id_kontributor`),
  KEY `FK__artikel` (`id_artikel`),
  KEY `FK__kategori` (`id_kategori`),
  KEY `FK__penulis` (`id_penulis`),
  CONSTRAINT `FK__artikel` FOREIGN KEY (`id_artikel`) REFERENCES `artikel` (`id_artikel`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK__kategori` FOREIGN KEY (`id_kategori`) REFERENCES `kategori` (`id_kategori`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK__penulis` FOREIGN KEY (`id_penulis`) REFERENCES `penulis` (`id_penulis`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Membuang data untuk tabel webpage.kontributor: ~2 rows (lebih kurang)
INSERT INTO `kontributor` (`id_kontributor`, `id_penulis`, `id_kategori`, `id_artikel`) VALUES
	(1, 1, 1, 1),
	(10, 1, 1, 15);

-- membuang struktur untuk table webpage.penulis
DROP TABLE IF EXISTS `penulis`;
CREATE TABLE IF NOT EXISTS `penulis` (
  `id_penulis` int NOT NULL AUTO_INCREMENT,
  `nama_penulis` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_penulis`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Membuang data untuk tabel webpage.penulis: ~1 rows (lebih kurang)
INSERT INTO `penulis` (`id_penulis`, `nama_penulis`, `email`, `password`) VALUES
	(1, 'admin', 'admin1@gmail.com', 'admin123');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
